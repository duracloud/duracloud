The files under 'fake-tomcat' are designed to test:
- swapping of ports in server.xml from 8xxx to new port
- setting permissions of *.sh files to executable

